<?php

namespace App\Hooks;

Class HookClass
{

    public function key_authorizer()
    {
        $session = \Config\Services::session();
        
        $request = \Config\Services::request();
        $key = $request->getVar('api_key');
        $auth_key = $session->api_key;
       
        if(!isset($key))
        {
            $data = array (
                'msg' => 'Api Key Required',
                'status' => 'fail',
                'code'   => 326
            );
            echo json_encode($data);
            die();
        }

        if(isset($key) == $auth_key)
        {   
            $uri = $_SERVER['REQUEST_URI'];
            redirect()->to($uri);
        } 
        else
        {
            $data = array (
                'msg' => 'Api key expired , Invalid , regenerate again',
                'status' => 'fail',
                'code'   => 326
            );
            echo json_encode($data);
            die();
        }
    }



}




?>