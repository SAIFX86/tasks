<!DOCTYPE html>
<head>
<title>Upload Deta</title>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<style>
.separator {
  display: flex;
  align-items: center;
  text-align: center;
}

.separator::before,
.separator::after {
  content: '';
  flex: 1;
  border-bottom: 1px solid #000;
}

.separator:not(:empty)::before {
  margin-right: .25em;
}

.separator:not(:empty)::after {
  margin-left: .25em;
}
</style>
<body>
<div class="container">
    <div class="row">
    <div class="col-md-8">
    <h3>
    <?php 
    $session = \Config\Services::session();
    if(($session->getFlashdata('error')!=NULL))
    { ?>
    <div class="alert alert-danger" role="alert">
           <?php echo $session->getFlashdata('error'); ?>
        </div>
    <?php }
       
    elseif(($session->getFlashdata('msg')!=NULL))
    { ?>
    <div class="alert alert-success" role="alert">
           <?php echo $session->getFlashdata('msg'); ?>
        </div>
    <?php }
    ?>    
   
    
    </h3>
    <span ><h3 color:blue>Download the template from below and Upload here</h3></span>
    <div class="alert alert-info" role="alert">
    <b>Note:</b><br>
    Do not modify the file name or column name inside it, just fill data n upload<br> 1> First Upload User Data<br> 2> Upload Job Tilte <br>3> Uploading Same File Again with different activity log will be updated<br> 4> Dont not use "  or ' in data file
    </div>
       <form class="" action="<?php echo base_url();?>/Home/upload_user_info1" method="post" enctype="multipart/form-data">
            <div class="input-group mb-3">
            <div class="form-group">
                <label for="exampleFormControlFile1">Select file to upload</label>
                <input type="file" class="form-control-file" name="csvfile" id="exampleFormControlFile1">
            </div>
            </div>
            <div class="input-group mb-3">
            <div class="input-group-prepend">
                <label class="input-group-text" for="">Options</label>
            </div>
            <select class="custom-select form-control" name="category" id="">
                <option selected>Choose...</option>
                <option value="user_details">User Details</option>
                <option value="user_job">Job Title</option>
            </select>
            </div>
            <button type="submit" name="submit" class="btn btn-primary btn-lg btn-block form-control">Click to Upload</button>
        </form>
        <a href="..\public\ExportCSV_JOB_PROFILE.csv">Download Job Title Template</a></br>
                         <div class="separator">OR</div>
        <a href="..\public\ExportCSV_USER_DATA.csv">Download User Details Template</a>
    </div>
    
        </div>
</div>

</body>


</html>