<?php

namespace App\Controllers;

use App\Models\UsersModel;
use DateTime;

class Home extends BaseController
{
	public function index()
	{
		return view('welcome_message');
	
	}
	public function upload_user_info()
	{
		return view('upload_user');
	}
	public function upload_user_info1()
	{
		if(isset($_POST['submit']))
		{	
			$session = \Config\Services::session();
			$userModel = new UsersModel();
			$db = \Config\Database::connect(); 
			$category = $this->request->getVar('category');
			
			$allowed_mime_type = array(
				'application/vnd.ms-excel'

			);
		    if(isset($_FILES['csvfile']['name']) && $_FILES['csvfile']['name']!="")
			{		
				$ext = $_FILES['csvfile']['type'];
				if(!in_array($ext,$allowed_mime_type))
				{
					
					$session->setFlashdata('error', 'File is not a Excel File(csv format) recheck the file properly before uploading');
					return redirect()->to(site_url('home/upload_user_info'));
					
				}
						
					

			}
		    
			if($category=='user_details')
			{
				if($_FILES['csvfile']['name']!="ExportCSV_USER_DATA.csv")
				{
					$session->setFlashdata('error', 'Wrong Template Selection');
					return redirect()->to(site_url('home/upload_user_info'));
				}


				$count=0;
				try{

				$fp = fopen($_FILES['csvfile']['tmp_name'],'r');
				}
				catch(\Exception $e){
					die($e->getMessage());
				}
				while($csv_lines = fgetcsv($fp,10000))
				{
					        $count++;
							if($count == 1)
							{
								continue;
							}
					       
						$data = array (
							'email_address'    => trim($csv_lines[0]),
							'name'             => trim($csv_lines[1]),
							'address'          => trim($csv_lines[2]),
							'activity_log'     => trim($csv_lines[3]),
							'dob'              => date("Y-m-d",strtotime($csv_lines[4]))
						);
						//print_r($data);
						$db = \Config\Database::connect();
						$email = $data['email_address'];
						$activity_log  = trim($csv_lines[3]);
					    $query = $db->query("SELECT email_address,activity_log FROM users_information WHERE email_address = '$email' ");
						$query = $query->getRow();
						
						//print_r($query);
						if(isset($query))
						{								
							
						    $query1 ="INSERT INTO users_information_old (user_id,name,email_address,address,activity_log,dob)
							SELECT user_id,name, email_address,address,activity_log,dob
							FROM users_information
							WHERE email_address='$email' AND activity_log < '$activity_log'";
							$db->query($query1);
							
							$userModel
							->where('email_address', $email)
							->set($data)
							->update();
							
							
							if($query->email_address == trim($csv_lines[0]))
							{
								
								$query1 ="INSERT INTO users_information_dup (name,email_address,address,activity_log,dob)
								SELECT name, email_address,address,activity_log,dob
								FROM users_information
								WHERE email_address='$email' AND activity_log = '$activity_log'";
								$db->query($query1);
								

							}
								

						}
						else
						{
								$userModel->insert($data);
						}

						
				}// end of while loop
				fclose($fp);
				$session->setFlashdata('msg', 'Data Succesfully Inserted');
				return redirect()->to(site_url('home/upload_user_info'));
								
			}//eof user_info
			elseif($category=='user_job')
			{
				if($_FILES['csvfile']['name']!="ExportCSV_JOB_PROFILE.csv")
				{
					$session->setFlashdata('error', 'Wrong Template Selection');
					return redirect()->to(site_url('home/upload_user_info'));
				}

				$count=0;
				try{
				$fp = fopen($_FILES['csvfile']['tmp_name'],'r');
				}
				catch(\Exception $e)
				{
					die($e->getMessage());
				}
				while($csv_lines = fgetcsv($fp,10000))
				{
					        $count++;
							if($count == 1)
							{
								continue;
							}
					       
						$data = array (
							'job_title'     =>     trim($csv_lines[0]),
							'email_address'     => trim($csv_lines[1])

						);
						//print_r($data);
						
						$email = $data['email_address'];
						$job_title  = $data['job_title'];
						//echo "SELECT email_address,job_title FROM users_information WHERE email_address = '$email'";
					    $query = $db->query("SELECT email_address,job_title FROM users_information WHERE email_address = '$email'");
						$row= $query->getRow();
						$datetime = date("Y-m-d H:i:s");

						//print_r($row->email_address);
						
						if(isset($row))
						{	
							
							if($row->job_title == '' && $row->email_address != '')
							{
								$userModel
								->where('email_address', $email)
								->set('job_title',$job_title)
								->update(); 
							}
							elseif($row->email_address != '' && $row->job_title != '')
							{
								$query1 ="INSERT INTO users_information_old (user_id,name,email_address,address,activity_log,dob,job_title)
								SELECT user_id,name,email_address,address,activity_log,dob,job_title
								FROM users_information
								WHERE email_address='$email' AND activity_log < '$datetime'";
								$db->query($query1);

								$userModel
								->where('email_address', $email)
								->set('job_title',$job_title)
								->update(); 
							}
							else{
								continue;
							}

						} 
						else
						{
							//$userModel->insert($data);
							continue;
						}
						
				}// end of while loop
						
				fclose($fp);
				$session->setFlashdata('msg', "Data Succesfully Inserted as $category");
				return redirect()->to(site_url('home/upload_user_info'));
						
				}// end of category user_job

				else{

					$session->setFlashdata('error', 'Category type not selected from drop down ');
					return redirect()->to(site_url('home/upload_user_info'));

				   } 
				   
				
		}// end off isset('$_POST['submit'])
			

	}// end of upload_user_info1()


		public function api_key_generate()
		{
			$email_address = $this->request->getVar('email_address');
			$db = \Config\Database::connect();
			$session = \Config\Services::session();
			
			$query = $db->query("SELECT email_address FROM users_information WHERE email_address= '$email_address' ");
			$res = $query->getRow();
			if(isset($res))
			{
				
					$email = $res->email_address;
					$data = array(
						'api_key' => sha1($email_address),
						'status'  => '200',
						'msg'     => 'Key Generated'
					);

			$user_details = array (
				'email_address' => $email_address,
			    'api_key'=> sha1($email_address)
			);
			$session->set($user_details);			
			echo json_encode($data);

			}
			else
			{
				$data = array (
					'msg' => 'Email not registered with us / email not authorized',
					'status' => 'false',
					'code'   => 326

				);
				echo json_encode($data);
			}
			

		}



		
}//eof class

?>
