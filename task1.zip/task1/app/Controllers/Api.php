<?php


namespace App\Controllers;
header('Content-Type: application/json');
use App\Models\UsersModel;
use App\Hooks\HookClass;
use CodeIgniter\Events\Events;
use CodeIgniter\Exceptions\FrameworkException;
 
class Api extends BaseController
{
    function __construct()
    {   
        $api_key_check = new HookClass;
        Events::on('post_controller_constructor',[$api_key_check,"key_authorizer"]);
    }

    public function user_details()
    {
        $email = $this->request->getVar('email_address');
        if(!isset($email))
        {   
            $data = array(
                'msg' => 'Mandatory Fields Missing / Some Fields Missing',
                'status' =>'fail',
                'code'   =>300
            );
            echo json_encode($data);
            die();
        }
        //$txt = preg_replace('/\W/',' ', $email); //replace non-word into space
        $txt= preg_replace('/\s+/', ' ', $email); //remove extra spaces
        $txt = trim($txt);
        $txt = explode(' ', $txt);
        $txt = array_unique($txt);
        $txt = implode( ",", $txt);
        $txt = "'" . str_replace(",", "','", $txt) . "'";
       
        $db= \Config\Database::connect();

        $query = $db->query("SELECT * FROM users_information WHERE email_address IN ($txt) GROUP BY email_address");
        
        $res = $query->getResultArray();

        if($res!=null)
        {
            echo json_encode($res);
        }
        else
        {
            $data = array(
                'msg' => 'No record found',
                'status' =>'success',
                'code'   =>200
            );
            echo json_encode($data);
        }
        
        
        
    }
    public function user_by_job_title()
    {

       
        $job_title = $this->request->getVar('job_title');
        if(!isset($job_title))
        {   
            $data = array(
                'msg' => 'Mandatory Fields Missing / Some Fields Missing',
                'status' =>'fail',
                'code'   =>300
            );
            echo json_encode($data);
            die();
        }
        
        $txt = preg_replace('/\W/',' ', $job_title); //replace non-word into space
        $txt= preg_replace('/\s+/', ' ', $txt); //remove extra spaces
        $txt = trim($txt);
        $txt = explode(' ', $txt);
        $txt = array_unique($txt);
        $txt = implode( ",", $txt);
        $txt = "'" . str_replace(",", "','", $txt) . "'";
        
        $db= \Config\Database::connect();
 

        
        $result = $db->query("SELECT job_title,count(user_id) as count FROM users_information WHERE job_title IN ($txt) GROUP BY job_title");
        $result = $result->getResultArray();

        if($result!=null)
        {
            echo json_encode($result);
        }
        else{
            $data = array(
                'msg' => 'No record found',
                'status' =>'success',
                'code'   =>200
            );
            echo json_encode($data);
        }
        

    }

}

?>